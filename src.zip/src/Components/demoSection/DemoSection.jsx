import React, { useState } from 'react';
import './DemoSection.css';
import image1 from '../../asest/2 1.png';

const DemoSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
  };

  return (
    <section className="demo-section">
      <div className="demo-grid">
        {/* Left side - Astronaut Image */}
        <div className="image-container">
          <img 
            src={image1} 
            alt="Astronaut with Bike"
            className="astronaut-image" 
          />
          <div className="image-overlay"></div>
        </div>

        {/* Right side - Demo Form */}
        <div className="form-container">
          <div className="form-content">
            <h2>Evolutionize Your Bike</h2>
            <h3>Get A Free Live Demo.</h3>
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <input
                  type="text"
                  name="name"
                  placeholder="Name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              
              <div className="form-group">
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>

              <button type="submit" className="submit-button">
                SUBMIT
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DemoSection;
